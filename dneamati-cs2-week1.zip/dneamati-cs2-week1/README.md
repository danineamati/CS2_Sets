Caltech CS2 Assignment 1: Introduction to C++

See [assignment1.html](http://htmlpreview.github.io/?https://github.com/caltechcs2/cpp_intro/blob/master/assignment1.html)

Name: Daniel Neamati
CMS username: dneamati